name = 'python programming'

print(name.capitalize())

print("Upper case :", name.upper())

print("lower case :", name.lower())

# display string in center of 40 spaces
print(name.center(40))

print(name.center(40,"*"))

print(name.count("p"))

print(name.isupper())

print(name.islower())

print(name.endswith("z"))

print(name.startswith("p"))

name = "  python "
print(name.strip())  # will remove spaces
print(name.lstrip())  # ONLy left side
print(name.rstrip())  # NLY right side

name = "python:programming"
output = name.split(":")
print("After split :", output)



