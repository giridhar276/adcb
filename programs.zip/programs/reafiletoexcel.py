
import os
import sys
import csv
from openpyxl import Workbook
try:
    wb = Workbook()
    # grab the active worksheet
    ws = wb.active

    filename = "realestate.csv"
    if os.path.isfile(filename):
        fobj = open(filename)
        reader = csv.reader(fobj)
        for line in reader:
            getlen = len(line)
            if getlen > 0 :
                ws.append(line)
        wb.save("today.xlsx")
    else:
        print("file doesn't exist")
        
except Exception as err:
    print("Exception found.. please check",err)        
            
    
    