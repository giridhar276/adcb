def getincrement(x):
    return x + 1
if __name__ == "__main__":
    alist =[10,20,30]
    print(list(map( getincrement , alist)))

    
## using lambda

if __name__ == "__main__":
    alist =[10,20,30]
    print(list(map( lambda  x: x + 1 , alist)))
