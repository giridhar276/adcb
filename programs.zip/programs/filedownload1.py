### method2   -  builtin library

import urllib.request as url

urllink = "http://samplecsvs.s3.amazonaws.com/Sacramentorealestatetransactions.csv"
filename = urllink.split("/")[-1]
url.urlretrieve(urllink,"C:\\Users\\GBMAUHTRN\\Desktop\\" + filename)