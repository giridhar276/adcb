



 

flag = "invalid"
while flag != "valid":
    password  = input("Enter password :")
    if len(password) > 4 :
        print("password is valid")
        flag ="valid"  
    else:
        print("Invalid password")
        
