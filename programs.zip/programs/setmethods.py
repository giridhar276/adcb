

aset = {"host1","host2","host3"}
bset = {"host3","host4"}

print(aset)
print(bset)

print(aset.union(bset))

print(aset.intersection(bset))

print(aset.difference(bset))

aset = {"host1","host2","host3"}
bset = {"host3","host4"}