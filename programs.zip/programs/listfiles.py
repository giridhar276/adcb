
import os

try:
    for file in os.listdir():
        print(file)
except Exception as err:
    print("Exception found ")
    print("Error :", err)
    

# display file of C:
os.chdir("C:\\")
try:
    for file in os.listdir( ):
        print(file)
except Exception as err:
    print("Exception found ")
    print("Error :", err)   