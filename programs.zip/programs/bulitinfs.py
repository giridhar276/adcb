name = input("Enter any name :")
print("You enteredd :", name)
### range(start,stop,step)
print(list(range(1,10)))
print(list(range(10,20)))
## display all ODD numbers
print(list(range(1,20,2)))
# display all even numbers
print(list(range(2,20,2)))

name  = "python"
print("length of the string :", len(name))

alist = [10,20,30]
print("length of the list   :", len(alist))

adict = {"chap1":10 ,"chap2":20}
print("length of the dictionary :", len(adict))

print(id(name))
print(id(alist))

print(type(name))
print(type(alist))

print(isinstance(name,str))
print(isinstance(name,list))
print(isinstance(alist,list))
print(isinstance(alist,tuple))

