
book   = { "chap1":10 ,"chap2":20  , "chap3":30 }



print(book["chap1"])  #10

print(book["chap2"])  #20

print(book["chap3"])


book["chap1"] = 100

print("After modifying :", book)

book["chap4"] = 40

print("Dictionary :", book)