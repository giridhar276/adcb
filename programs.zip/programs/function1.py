# fixed arguments
# function call
def display(first,second):
    print(first)
    print(second)

# calling function
display(10,20)