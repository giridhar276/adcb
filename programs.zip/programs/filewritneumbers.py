

fobj = open("clients.txt","w")


for val in range(1,10):
    fobj.write(val + "\n")

fobj.close()
