book1 = {"chap1":[10,"Alen","India"] ,"chap2":[20,"Jessy","India"]}
print(book1)

print(book1["chap1"])


book2 = {"chap1":{"author":"jessy","pages":10} ,"chap2":{"author":"ALen","pages":100}}

print(book2)

print(book2["chap1"])

print(book2["chap2"])


print(book2["chap1"]["author"])
print(book2["chap1"]["pages"])

print(book2["chap2"]["author"])
print(book2["chap2"]["pages"])