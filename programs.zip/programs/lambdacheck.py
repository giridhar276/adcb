def add(first,second):
    return first + second

getsum = add(1,2)
print(getsum)

# with lambda
print("--------------usin lambda --------------")
add  = lambda first,second : first + second
print(add(1,2))



def toupper(name):
    return name.upper()

name = "python"
output = toupper(name)
print("Upper case :", output)

## using lambda  ######
name = "python"
toupper = lambda name : name.upper()
print("Upper cae :" , toupper(name)
