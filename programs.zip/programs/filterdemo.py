

alist = [1,2,3,4,45,45,454,545,4545343,6545,5,6]

# write a program to display ONLY even numbers from the above list


even = []
for val in alist:
    if val %2 == 0:
        even.append(val)

print(even)


## using filter
# map(function, list)  or map(lambda,list)
# filter(function,list)or filter (lambda , list)

alist = [1,2,3,4,45,45,454,545,4545343,6545,5,6]
print(list(filter(lambda x : x %2 == 0 , alist)))
        

