# tuple demo

atup = (10,20,30,40,50,60)

print(atup[0])

print(atup[4:8])

#atup[0] = 1000

print("After modifying :", atup)