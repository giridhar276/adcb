





if __name__ == "__main__":
    name = input("Enter any string :")
    print( str(lambda name : name.upper()))
 
