ydict = {
"id": "0001",
"type": "donut",
"name": "Cake",
"image":{
"url": "images/0001.jpg",
"width": 4000,
"height": 200 },
}

for item in ydict:
    if isinstance(ydict[item],str):
        print(ydict[item])
    elif isinstance(ydict[item],dict):
        print(ydict[item]["url"])
        print(ydict[item]["width"])
        print(ydict[item]["height"])
















'''
for item in ydict:
    if not isinstance(ydict[item],int):
        print(ydict[item])
    elif isinstance(ydict[item],dict):
        print(ydict[item]['width'])
        print(ydict[item]['height'])
        print(ydict[item]['url'])
    print("--------------------------")
 '''       