


 
import glob
for record in glob.glob("C:\\Users\\GBMAUHTRN\\Desktop\\programs\\*.py"):
    print(record)





