


name = "python"

if name.isupper():
    print("string is upper")
elif name.islower():
    print("string is lower")