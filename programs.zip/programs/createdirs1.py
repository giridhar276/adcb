import os

for val in range(1,10):
    dirname = "dir" + str(val)
    os.mkdir(dirname)
