
def toupper(newname):
    return newname.upper()


if __name__ == "__main__":
    name = input("Enter any string :")
    name = toupper(name)
    print(name)
