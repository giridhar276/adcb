

alist = ['1','2','3']
#[1,2,3]
blist = []
for val in alist:
    blist.append(int(val))
print(blist)



## using lambda

print(list(map(lambda x : int(x), alist)))


## directly converting to int
print(list(map(int , alist)))



alist = ["google","oracle","microsoft"]
print(list(map(lambda x : "www." + x + ".com", alist)))
