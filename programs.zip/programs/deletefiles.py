#write a program to delete all the .csv files from the current directory
import os

for file in os.listdir():
    if os.path.isfile(file) and file.endswith(".csv"):
        print(file)
        
# display files and the size
import os
for file in os.listdir():
    if os.path.isfile(file):
        getsize = os.path.getsize(file)
        print("File name :", file)
        print("Size      :", getsize , "bytes")
        print("----------------------------")
        