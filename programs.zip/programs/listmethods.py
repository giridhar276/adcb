
alist = [10,20,30,40,10]
# append : adding single value
alist.append(50)
print("After appending :", alist)
alist.append(60)
print("After appending :", alist)

# extend : adding multiple values
alist.extend([70,80,90])
print("After extending :", alist)

print("Count of 10 :", alist.count(10))

print("Get index :",alist.index(20))

# pop based on the index
alist.pop(0)
print("After pop operation :", alist)

alist.pop()
print("After pop operation :", alist)

alist.remove(20)
print("After removing :", alist)

## insert( where to insert , what to insert)
alist.insert(0,10)
alist.insert(3,20)
print("After inserting :", alist)

# display in sorting order
alist.sort()
print("Ascending order :", alist)

alist.reverse()
print("Reverse order :", alist)





