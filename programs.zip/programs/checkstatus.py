

import requests
url = "https://www.google.com"

status = requests.get(url)

print("Status code :", status.status_code)
### contains HTML code
#print(status.text)


#### program2
fobj = open("urls.txt")

for line in fobj:
    line = line.strip()
    status = requests.get(url)
    print("URL   :", line)
    print("Status:", status.status_code)
    print("--------------------------")
    