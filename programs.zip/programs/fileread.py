import csv
fobj = open("realestate.csv")
# converting fobj to csv object
reader = csv.reader(fobj)  # csv object

for line in reader:
    print(line)

 
    
#########################################
fobj = open("realestate.csv")

for line in fobj:
    line = line.strip()
    output= line.split(",")
    print(output)

