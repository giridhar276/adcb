


name = "python programming"
print(name)

#string[start:stop:step]
print(name[0])
print(name[1])
print(name[0:4])

print(name[3:])

print(name[::])    

print(name[3:8])

print(name[0:15:2])

print(name[::2])

print(name[0:15:3])

print(name[-1])

print(name[-4:-2])

print(name[::-1])







