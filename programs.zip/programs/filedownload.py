

### method 1   - third party library

import wget

wget.download("http://spatialkeydocs.s3.amazonaws.com/FL_insurance_sample.csv.zip")


### method2   -  builtin library

import urllib.request as url

urllink = "http://samplecsvs.s3.amazonaws.com/Sacramentorealestatetransactions.csv"
filename = urllink.split("/")[-1]
url.urlretrieve(urllink,filename)

