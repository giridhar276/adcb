

import os
from openpyxl import Workbook
import time

wb = Workbook()

# grab the active worksheet
ws = wb.active


for file in os.listdir():
    ws.append([file])
    
wb.save(time.strftime("%d_%b_%Y.xlsx"))