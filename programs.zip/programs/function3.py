
# tuple format
def display(*info):
    print(info)
    for val in info:
        print(val)
# calling function
display(10,20,30,40,50,"unix","linux")


#  ** is the dictionary
def displayinfo(**data):
    print(data)

displayinfo(chap1 = 10 , chap2 = 20)