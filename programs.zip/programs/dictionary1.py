infodoc =  { 2001: {"ap":70}  , 2002:{"tn":75} , 2003:{"up":50} }
print("city rate")
for key in infodoc:
    info =infodoc[key]
    city = list(info.keys())
    rate = list(info.values())
    print(city[0],rate[0])
 
    
    
infodoc =  { 2001: {"ap":70}  , 2002:{"tn":75} , 2003:{"up":50} }
print("city rate")
print("----------")
for key in infodoc:
    info =infodoc[key]
    city = list(info.keys())
    rate = list(info.values())
    rate[0] = str(rate[0])
    print(city[0].ljust(5),rate[0].ljust(5))
     