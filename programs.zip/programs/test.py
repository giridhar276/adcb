

info  ={ "colors": "red", "values": "#f00" }


print(list(info.values()))
