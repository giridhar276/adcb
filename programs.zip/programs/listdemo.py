

alist = [10,20,30,40,50,60,70]

print(alist)

print(alist[0])

print(alist[1])

print(alist[0:4])

print(alist[-1])

# reverse all the elements of the list
print(alist[::-1])

alist[0] =100

print("After modifying :", alist)