import pymysql


db = pymysql.connect("127.0.0.1","root","passw0rd")
print(db)
 
if db is not None :
    cursor = db.cursor()
    query = "create database adcb"
    cursor.execute(query)
    

db.close()
