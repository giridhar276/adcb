
try:
    filename = input("Enter any file :")
    
    fobj = open(filename,"r")
    
    for line in fobj:
        # remove the white spaces at the end of the string
        line = line.strip()
        print (line)   
    fobj.close()
    
    final = "hi" + 10
    print(final)

except Exception as err:
    print("Exception found.. please check")
    print("System error :",err)
 