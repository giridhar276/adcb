

## comanmd line arguments
# passing arguments from the command line

import sys

#print(sys.argv)

for item in sys.argv:
    print(item)