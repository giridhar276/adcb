

def getincrement(data):
    output = []
    for val in data:
        output.append(val + 1)
    print(output)


if __name__ == "__main__":
    alist =[10,20,30]
    getincrement(alist)
