import pymysql


db = pymysql.connect("127.0.0.1","root","passw0rd","adcb")
 
if db is not None :
    cursor = db.cursor()
    query = "select * from realestate"
    cursor.execute(query)
    for record in cursor.fetchall():
        print(record[0],record[1])
        
    query = "insert into realestate values('{}','{}')".format('MG Road','Delhi')
    cursor.execute(query)
    db.commit()
    print("After inserting")
    print("---------------------")
    query = "select * from realestate"
    cursor.execute(query)
    for record in cursor.fetchall():
        print(record[0],record[1])    

db.close()