

print("python programming")

print(1,2,3)

print('unix','oracle','java')