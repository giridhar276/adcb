


import psutil

print(psutil.cpu_percent())

 
cpupercent = psutil.cpu_percent()

if int(psutil.cpu_percent())  > 15 :
    print("cpu utlization is greater than 15%")

 

print(psutil.disk_usage("C:\\"))

print(psutil.net_connections(kind='inet'))

 