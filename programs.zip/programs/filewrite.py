


fobj = open("clients.txt","w")


fobj.write("python programming\n")  
fobj.write("unix shell progrmaming\n")

fobj.close()
