def getoutput():
    colors = [
    {
    "colors": "red",
    "values": "#f00"
    },
     {
    "colors": "blue",
    "values": "#00f"
    }
    ]   
    print("------------------------")
    ## witout hardcoding 
    for item in colors:
        data = list(item.values())
        print(data[0].ljust(7) , data[1].ljust(7))
        
    
if __name__ == "__main__":
    getoutput()
    displayoutput()
    readfile()
    writefile()