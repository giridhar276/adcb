


print(__name__)