
str = "hello world"

# if you see a output message, complete string

print(str)

#You will get the first character of the string
print("first character of string :", str[0] )

# when required the string starting from 3rd to 5th
print("the string starting from 3rd to 5th :", str[2:5])

#when required the string starting from 3rd character
print("The string starting from 3rd :",str[2:])

# to print string two times
print("the string two times :", str * 2 )

# to print concatenated string with "test"
print("concatenated string :", str + "test")
