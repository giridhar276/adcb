def marksInfo():
    print("hello... I am marks...")
